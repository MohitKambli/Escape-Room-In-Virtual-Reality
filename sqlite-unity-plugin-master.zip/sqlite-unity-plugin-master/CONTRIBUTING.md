Contributions are accepted if they propose improvement in usability and effectiveness of the plugin.
